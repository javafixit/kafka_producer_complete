package com.javainfinite.kafka.producer.model;

public enum LibraryEventType {

    NEW,
    UPDATE
}
